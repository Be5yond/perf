#!bin/bash

# install dependency
yum install -y gcc perl 
## glibc ncurses
yum install -y SDL-devel mesa-libGL-devel

yum install -y libaio gnuplot

# install ubench & unixbench
rpm -ivh ubench-0.32-1.el6.x86_64.rpm
tar xzvf unixbench-5.1.2.tar.gz

# install fio
rpm -ivh fio-2.0.10-1.el6.rf.x86_64.rpm

# install iperg
rpm -ivh epel-release-6-8.noarch.rpm
yum install -y iperf
## dstat iptraf

# get speedtest script
# wget https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py
